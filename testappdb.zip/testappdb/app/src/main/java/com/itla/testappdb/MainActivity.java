package com.itla.testappdb;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.itla.testappdb.entidades.Estudiante;
import com.itla.testappdb.repositorio.EstudianteRepositorio;
import com.itla.testappdb.repositorio.EstudianteRepositorioDblmpl;

public class MainActivity extends AppCompatActivity {

    EstudianteRepositorio estudianteRepositorio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        estudianteRepositorio = new EstudianteRepositorioDblmpl(this.getBaseContext());

        Estudiante est1 = new Estudiante();
        est1.setNombre("juan sito sport");
        est1.setMatricula("MAT01");

        estudianteRepositorio.crear(est1);

        Estudiante est2 = new Estudiante();
        est2.setNombre("juan sito roma");
        est2.setMatricula("MAT02");
        estudianteRepositorio.crear(est2);

    }



}
